--This procedure creates entry in various table for the sample enterprise AC

DECLARE

	nameEnterprise ENTERPRISE.NAME%TYPE := 'FC500';
	idEnterprise ENTERPRISE.ID%TYPE := 1005;
	idOrganization ORGANIZATION.ID%TYPE := 1006;
	nameMember MEMBER.USERNAME%TYPE := 'tadmin';

	idModMember MEMBER.ID%TYPE;
	idMember MEMBER.ID%TYPE;

	idFunc FUNCTION.ID%TYPE;
	idRole ROLE.ID%TYPE;
	idRole2FuncMap ROLE2FUNCMAP.ID%TYPE;
	idRuleMetaModel RULEMETAMODEL.ID%TYPE;
	idRuleModel RULEMODEL.ID%TYPE;
	rowCount INTEGER;
	
	TYPE T_ROLES_REC IS RECORD
	  (
		name varchar2(100),
		description varchar2(2000)
	  );

	TYPE T_FUNCTIONS_REC IS RECORD
	  (
		rolename varchar2(100),
		functionname varchar2(100),
		priority number(1)
	  );
	  
	TYPE T_RULEMETAMODEL_REC IS RECORD
	  (
		name varchar2(100),
		type varchar2(100),
		description varchar2(2000),
		active char(1),
		rulemetamodel varchar2(2000)
	  );
	  
	TYPE T_RULEMODEL_REC IS RECORD
	  (
		rulesetname varchar2(100),
		rulemodel varchar2(2000),
		rulemodelname varchar2(2000)
	  );

	TYPE T_RULEMODELPARAMETER_REC IS RECORD
	  (
		rulesetname varchar2(200),
		ownertype varchar2(30),
		parameterposition number(10),
		parameternumber	varchar2(80),
		parametertype	varchar2(30),
		associatedobjecttype	varchar2(30),
		definition	varchar2(80),
		predefined	char(1)
	  );
	  
	TYPE T_ROLES_TAB IS TABLE OF T_ROLES_REC INDEX BY PLS_INTEGER;

	TYPE T_FUNCTIONS_TAB IS TABLE OF T_FUNCTIONS_REC INDEX BY PLS_INTEGER;

	TYPE T_RULEMETAMODEL_TAB IS TABLE OF T_RULEMETAMODEL_REC INDEX BY PLS_INTEGER;

	TYPE T_RULEMODEL_TAB IS TABLE OF T_RULEMODEL_REC INDEX BY PLS_INTEGER;

	TYPE T_RULEMODELPARAMETER_TAB IS TABLE OF T_RULEMODELPARAMETER_REC INDEX BY PLS_INTEGER;

	roles T_ROLES_TAB;
	functions T_FUNCTIONS_TAB;
	rulemetamodels T_RULEMETAMODEL_TAB;
	rulemodels T_RULEMODEL_TAB;
	rulemodelparameters T_RULEMODELPARAMETER_TAB;

BEGIN
	<roles>
	<functions>
	<rulemetamodels>
	<rulemodels>
	<rulemodelparameters>

	SELECT ID INTO idModMember FROM MEMBER WHERE USERNAME = nameMember;

	INSERT INTO ENTERPRISE(ID, "NAME", INTERNALNAME, SHORTNAME, ACTIVE, MODMEMBERID, MODDATE, VERTICAL)
	VALUES (idEnterprise, nameEnterprise, nameEnterprise, NULL, 'Y', NULL, NULL, NULL);
	
	INSERT INTO "ORGANIZATION"(ID, ENTERPRISEID, "NAME", "TYPE", DUNS, TAXID, ACTIVE, MODMEMBERID, MODDATE, MODVERSION, GLOBAL)
	VALUES (idOrganization, idEnterprise, nameEnterprise, 'SUPPLIER', '12345', NULL, 'Y', idModMember, TO_DATE('16-01-2003 03:11:55','DD-MM-YYYY HH:MI:SS'), '1', 'N');

	FOR i IN roles.FIRST .. roles.LAST LOOP
		BEGIN
			SELECT mq_sequence_1.NEXTVAL INTO idRole FROM DUAL;
			INSERT INTO ROLE (ID, ENTERPRISEID, NAME, DESCRIPTION, TYPE, ACTIVE, MODMEMBERID, MODDATE, MODVERSION, ORGANIZATIONTYPE)
			VALUES (idRole, idEnterprise, roles(i).name, roles(i).description, null, 'Y', idModMember, SYSDATE, 1, 'SUPPLIER');
			
			FOR j in functions.FIRST .. functions.LAST LOOP
				BEGIN
					IF functions(j).rolename = roles(i).name THEN
						SELECT COUNT(1) INTO rowCount FROM FUNCTION WHERE NAME = functions(j).functionname;
						IF rowCount > 0 THEN
							SELECT ID INTO idFunc FROM FUNCTION WHERE NAME = functions(j).functionname;
							SELECT mq_sequence_1.NEXTVAL INTO idRole2FuncMap FROM DUAL;
							INSERT INTO ROLE2FUNCMAP (ID, ROLEID, FUNCID, NAME, PRIORITY) VALUES (idRole2FuncMap, idRole, idFunc, roles(i).name, functions(j).priority);
						END IF;
					END IF;
				END;
			END LOOP;
		END;
	END LOOP;
	
	FOR i IN rulemetamodels.FIRST .. rulemetamodels.LAST LOOP
		BEGIN
			SELECT RULE_SEQ.NEXTVAL INTO idRuleMetaModel FROM DUAL;
			INSERT INTO RULEMETAMODEL (ID, ORGANIZATIONID, NAME, ACTIVE, MODMEMBERID, MODDATE, MODVERSION, TYPE, DESCRIPTION, RULEMETAMODEL)
            VALUES (idRuleMetaModel, idOrganization, rulemetamodels(i).name, rulemetamodels(i).active, idModMember, SYSDATE, 1, rulemetamodels(i).type, rulemetamodels(i).description, rulemetamodels(i).rulemetamodel);
			
		END;
	END LOOP;
	
	FOR i IN rulemodels.FIRST .. rulemodels.LAST LOOP
		BEGIN
			SELECT RULE_SEQ.NEXTVAL INTO idRuleModel FROM DUAL;
			INSERT INTO RULEMODEL (ID, ORGANIZATIONID, RULESETNAME, ACTIVE, MODMEMBERID, MODDATE, MODVERSION, RULEMODEL, RULEMODELNAME)
            VALUES (idRuleModel, idOrganization, rulemodels(i).rulesetname, 'Y', idModMember, SYSDATE, 1, rulemodels(i).rulemodel, rulemodels(i).rulemodelname);
		
			FOR j in rulemodelparameters.FIRST .. rulemodelparameters.LAST LOOP
				BEGIN
					IF rulemodelparameters(j).rulesetname = rulemodels(i).rulesetname THEN
						INSERT INTO RULEPARAMETER (OWNERID, OWNERTYPE, PARAMETERPOSITION, PARAMETERNUMBER, PARAMETERTYPE, ASSOCIATEDOBJECTYPE, DEFINITION, PREDEFINED)
                        VALUES (idRuleModel, rulemodelparameters(j).ownertype, rulemodelparameters(j).parameterposition, rulemodelparameters(j).parameternumber, rulemodelparameters(j).parametertype, rulemodelparameters(j).associatedobjecttype, rulemodelparameters(j).definition, rulemodelparameters(j).predefined);
					END IF;
				END;
			END LOOP;
		END;
	END LOOP;
	
	SELECT mq_sequence_1.NEXTVAL INTO idMember FROM DUAL;
	INSERT INTO MEMBER (ID, ENTERPRISEID, DOMAIN, USERNAME, LASTNAME, FIRSTNAME, MIDDLENAME, SECURITYTYPE, SECURITY, DESCRIPTION, ACTIVE, MODMEMBERID, MODDATE, MODVERSION, DELEGATIONACTIVE,DELEGATIONSTARTDATE, DELEGATIONENDDATE, NOTIFYOFDELEGATION, AUTOREVERTFLAG, LOCALE, "LANGUAGE", PARTITIONKEY )
    VALUES (idMember, idEnterprise, 'MartQuestNet', 'sample', 'admin', 'admin', 'admin', 'PASSWORD', 'euc!1d', NULL, 'Y', idModMember, SYSDATE, 1, 'N', NULL, NULL, NULL, NULL, 'null', 'null', 0);
	
	SELECT ID INTO idRole FROM ROLE WHERE ENTERPRISEID = idEnterprise AND NAME = 'Admin';
	
	INSERT INTO ROLEASSIGNMENT (ROLEID, MEMBERID, MEMBERVERSION, MODDATE, MODMEMBERID) VALUES (idRole, idMember, 1, SYSDATE, idModMember);
	
	INSERT INTO MEMBERSHIP (ORGANIZATIONID, MEMBERID) VALUES (idOrganization, idMember);

	COMMIT;

	EXCEPTION
		WHEN NO_DATA_FOUND THEN
          DBMS_OUTPUT.PUT_LINE('Error while executing script...');
		  ROLLBACK;
		  RAISE;
        WHEN OTHERS THEN
          ROLLBACK;
		  RAISE;

							
END;
/
